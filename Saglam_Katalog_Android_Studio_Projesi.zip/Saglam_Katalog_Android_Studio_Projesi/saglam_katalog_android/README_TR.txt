SAĞLAM KATALOG — ANDROID STUDIO PROJESİ

Bu klasör, Sağlam Katalog uygulamasının Android APK üretmek üzere hazırlanmış kaynak projesidir.
Özellikler:
- Android'in kendi fotoğraf seçicisiyle galeriden ürün fotoğrafı seçme
- Kare (1:1) çıktı, beyaz arka plan, çözünürlük seçimi
- PNG çıktısını Android Galeri/Pictures/SaglamKatalog klasörüne kaydetme
- WebViewAssetLoader ile uygulama içindeki HTML'i güvenli HTTPS benzeri origin'de açma

ÖNEMLİ SINIRLAMA
Arka planı yapay zekâyla kaldırma modeli ilk kullanımda internet üzerinden üçüncü taraf CDN'lerden yüklenir. Bu kaynaklar cihaz/ağ tarafından engellenirse model yine hata verebilir. Bu projede fotoğraf seçme ve PNG kaydetme Android'e bağlandı; modelin harici indirme altyapısı henüz cihaz üzerinde doğrulanmış değildir. Bu çalışma ortamında Android SDK/Gradle bulunmadığı için imzalı APK derlenip test edilemedi; bu nedenle bu ZIP bir APK değil, APK oluşturulabilir Android Studio projesidir.

APK oluşturma (Android Studio yüklü bilgisayarda):
1. ZIP'i açın.
2. Android Studio > Open ile SaglamKatalog klasörünü açın.
3. Gradle senkronizasyonunun bitmesini bekleyin (internet gerekir).
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. Derleme başarılı olursa APK'yı app/build/outputs/apk/debug/app-debug.apk konumunda bulabilirsiniz.

Minimum Android: 6.0 (API 23). Uygulama, arka plan kaldırma modelini indirmek için internet bağlantısı ister.

Bilgisayarınız yoksa: Projeyi kendi GitHub hesabınıza yükleyip Actions sekmesinden “Build Android APK” iş akışını çalıştırabilirsiniz. İşlem tamamlandığında “saglam-katalog-debug-apk” adlı artifact içinden APK indirilebilir. Bu adım GitHub hesabı ve proje yüklemesi gerektirir.
